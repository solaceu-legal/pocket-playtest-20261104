'use strict';

// Run with Node and FFmpeg. Only the original sample synthesizers are evaluated.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { execFileSync } = require('node:child_process');

if (!process.argv[2]) throw new Error('Usage: node export-original-audio.cjs original.html');
const html = fs.readFileSync(process.argv[2], 'utf8');
const start = html.indexOf('var vt=Math.PI*2;function ao(');
const end = html.indexOf('function a_(i,e=0,t)', start);
if (start < 0 || end <= start) throw new Error('Original audio synthesizer was not found');
const render = vm.runInNewContext(html.slice(start, end) + '\n; r_', {}, { timeout: 1000 });

const output = path.join(__dirname, 'wechat', 'audio');
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'dock04-samples-'));
fs.mkdirSync(output, { recursive: true });

function exportSample(file, name, variant = 0) {
  const { sr, ch } = render(name, variant);
  const samples = ch[0].length;
  const channels = ch.length;
  const size = samples * channels * 2;
  const wav = Buffer.alloc(44 + size);
  wav.write('RIFF', 0);
  wav.writeUInt32LE(36 + size, 4);
  wav.write('WAVEfmt ', 8);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(channels, 22);
  wav.writeUInt32LE(sr, 24);
  wav.writeUInt32LE(sr * channels * 2, 28);
  wav.writeUInt16LE(channels * 2, 32);
  wav.writeUInt16LE(16, 34);
  wav.write('data', 36);
  wav.writeUInt32LE(size, 40);
  for (let i = 0; i < samples; i++) {
    for (let c = 0; c < channels; c++) {
      wav.writeInt16LE(Math.round(Math.max(-1, Math.min(1, ch[c][i])) * 32767), 44 + (i * channels + c) * 2);
    }
  }
  const source = path.join(temporary, file + '.wav');
  fs.writeFileSync(source, wav);
  execFileSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-i', source,
    '-c:a', 'libmp3lame', '-q:a', '4', path.join(output, file + '.mp3')]);
}

try {
  for (let i = 0; i < 4; i++) exportSample('shot-' + i, 'rifle_shot', i);
  for (let i = 0; i < 4; i++) exportSample('step-' + i, 'step_concrete', i);
  const sounds = {
    rain: 'rain', hurt: 'hurt', ui: 'ui_click', win: 'complete', death: 'death',
    'reload-out': 'reload_magout', 'reload-in': 'reload_magin', 'reload-bolt': 'reload_bolt',
    relay: 'relay_cut', 'relay-all': 'objective_all', 'gull-fire': 'gull_fire',
    'hound-fire': 'hound_fire', 'gull-kill': 'gull_die', 'hound-kill': 'hound_die',
    hit: 'impact_enemy', alert: 'alert',
  };
  for (const [file, name] of Object.entries(sounds)) exportSample(file, name);
} finally {
  fs.rmSync(temporary, { recursive: true, force: true });
}
