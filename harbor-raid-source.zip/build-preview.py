"""Build a standalone browser preview from the same source as WeChat."""
from base64 import b64encode
from pathlib import Path
import json

root = Path(__file__).resolve().parent
source = root / "wechat"
modules = ",\n".join(
    f"{json.dumps(name)}:function(require,module){{\n{(source / name).read_text()}\n}}"
    for name in ("mission.js", "view.js", "runtime.js", "sound.js")
)
sounds = {
    p.stem: f"data:audio/mpeg;base64,{b64encode(p.read_bytes()).decode('ascii')}"
    for p in sorted((source / "audio").glob("*.mp3"))
}
template = r"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#101e1b">
<title>航战之港区奇袭</title>
<meta name="description" content="竖屏第一人称港区行动。切断三处中继，突破封锁，登船撤离。">
<style>
:root{color-scheme:dark;background:#101e1b}
*{box-sizing:border-box}
html,body{margin:0;width:100%;height:100%;overflow:hidden;overscroll-behavior:none}
body{font-family:system-ui,sans-serif;-webkit-user-select:none;user-select:none}
#field{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none;-webkit-tap-highlight-color:transparent}
#safe{position:fixed;visibility:hidden;pointer-events:none;top:env(safe-area-inset-top);right:env(safe-area-inset-right);bottom:env(safe-area-inset-bottom);left:env(safe-area-inset-left)}
#fallback{position:absolute;left:16px;right:16px;bottom:16px;color:#f2d0ad;background:#36261b;padding:14px;font-size:14px}
</style>
</head>
<body>
<canvas id="field" aria-label="航战之港区奇袭，第一人称射击游戏。按回车开始，用 WASD 移动。触屏可拖动左下摇杆移动、拖动右侧转向。"></canvas>
<div id="safe"></div>
<noscript><p id="fallback">请开启 JavaScript 后重新打开游戏。</p></noscript>
<script>
(() => {
'use strict';
const modules={
__MODULES__
};
const cache={};
function load(name){
  if(!cache[name]){
    const module={exports:{}};
    cache[name]=module;
    modules[name](path=>load(path.replace(/^\.\//,'')),module);
  }
  return cache[name].exports;
}
const soundSources=__SOUNDS__;
const pickSample=load('sound.js').createSamplePicker();
const AudioContextType=window.AudioContext||window.webkitAudioContext;
const decoded=new Map();
let audioContext, master, rain, fallbackRain;
let ambientWanted=false, audioEnabled=true;
const fallbackSounds=new Set();

function bufferFor(file){
  if(!decoded.has(file)){
    const packed=soundSources[file].split(',')[1];
    const bytes=Uint8Array.from(atob(packed),char=>char.charCodeAt(0));
    decoded.set(file,audioContext.decodeAudioData(bytes.buffer).catch(error=>{
      decoded.delete(file);console.warn('Harbor Raid audio decode',error);return null;
    }));
  }
  return decoded.get(file);
}
function unlockSound(){
  if(!AudioContextType)return;
  if(!audioContext){
    try {
      audioContext=new AudioContextType();
      master=audioContext.createGain();
      master.gain.value=audioEnabled?1:0;
      master.connect(audioContext.destination);
      for(const file of Object.keys(soundSources)) bufferFor(file);
    } catch(error) {
      audioContext=null;console.warn('Harbor Raid audio init',error);
    }
  }
  if(audioContext && audioContext.state!=='running') audioContext.resume().catch(()=>{});
}
function playSound(kind){
  if(!audioEnabled)return;
  const sample=pickSample(kind);
  if(!sample)return;
  if(!audioContext){
    const audio=new Audio(soundSources[sample.file]);
    audio.volume=sample.gain;
    fallbackSounds.add(audio);
    audio.addEventListener('ended',()=>fallbackSounds.delete(audio),{once:true});
    audio.play().catch(()=>fallbackSounds.delete(audio));
    return;
  }
  bufferFor(sample.file).then(buffer=>{
    if(!buffer || !audioEnabled || audioContext.state!=='running')return;
    const source=audioContext.createBufferSource();
    const gain=audioContext.createGain();
    source.buffer=buffer;gain.gain.value=sample.gain;
    source.connect(gain);gain.connect(master);
    source.onended=()=>{source.disconnect();gain.disconnect();};
    source.start();
  });
}
function ambience(on){
  ambientWanted=on;
  if(!on){
    if(rain){rain.stop();rain=null;}
    if(fallbackRain)fallbackRain.pause();
    return;
  }
  const sample=pickSample('rain');
  if(!audioContext){
    if(!fallbackRain)fallbackRain=new Audio(soundSources.rain);
    fallbackRain.loop=true;fallbackRain.volume=sample.gain;
    fallbackRain.play().catch(()=>{});
    return;
  }
  bufferFor('rain').then(buffer=>{
    if(!buffer || !ambientWanted || !audioEnabled || rain)return;
    rain=audioContext.createBufferSource();
    const gain=audioContext.createGain();
    rain.buffer=buffer;rain.loop=true;gain.gain.value=sample.gain;
    const source=rain;
    rain.connect(gain);gain.connect(master);
    rain.onended=()=>{source.disconnect();gain.disconnect();};
    rain.start();
  });
}
function setSound(on){
  audioEnabled=on;
  if(master)master.gain.value=on?1:0;
  if(!on){
    for(const audio of fallbackSounds)audio.pause();
    fallbackSounds.clear();
    ambience(false);
  }
}
const canvas=document.getElementById('field');
const safeNode=document.getElementById('safe');
const {createGame,movementKeys}=load('runtime.js');
let game;
try {
  game=createGame({
    canvas,
    createSurface(w,h){
      const surface=document.createElement('canvas');
      surface.width=w;surface.height=h;return surface;
    },
    measure(){
      const size=canvas.getBoundingClientRect(), style=getComputedStyle(safeNode);
      const safe={};
      for(const edge of ['top','right','bottom','left']) safe[edge]=parseFloat(style[edge])||0;
      return {w:size.width,h:size.height,dpr:window.devicePixelRatio,safe};
    },
    request:cb=>requestAnimationFrame(cb),
    cancel:id=>cancelAnimationFrame(id),
    reduced:()=>matchMedia('(prefers-reduced-motion: reduce)').matches,
    load(key){try{return JSON.parse(localStorage.getItem('dock04-'+key));}catch(_){return null;}},
    save(key,value){try{localStorage.setItem('dock04-'+key,JSON.stringify(value));}catch(_){}},
    sound:playSound,
    unlockSound,ambience,setSound,
    haptic(){if(navigator.vibrate)navigator.vibrate(24);},
  });
} catch (error) {
  console.error(error);
  const p=document.createElement('p');
  p.id='fallback';p.textContent='画面无法启动。请使用支持 Canvas 2D 的浏览器打开。';
  document.body.append(p);
  return;
}
canvas.addEventListener('pointerdown',event=>{
  if(event.button!==0)return;
  canvas.setPointerCapture(event.pointerId);
  game.down(event.pointerId,event.clientX,event.clientY);
});
canvas.addEventListener('pointermove',event=>game.move(event.pointerId,event.clientX,event.clientY));
canvas.addEventListener('pointerup',event=>game.up(event.pointerId,event.clientX,event.clientY));
canvas.addEventListener('pointercancel',event=>game.up(event.pointerId,event.clientX,event.clientY,true));
canvas.addEventListener('lostpointercapture',event=>game.up(event.pointerId,event.clientX,event.clientY,true));
canvas.addEventListener('contextmenu',event=>event.preventDefault());
window.addEventListener('keydown',event=>{
  if(movementKeys.has(event.code))event.preventDefault();
  game.key(event.code,true);
});
window.addEventListener('keyup',event=>game.key(event.code,false));
window.addEventListener('resize',game.resize);
document.addEventListener('visibilitychange',()=>document.hidden?game.hide():game.show());
window.addEventListener('pagehide',game.hide);
window.addEventListener('pageshow',game.show);
})();
</script>
</body>
</html>
"""
(root / "Dock04-Mobile.html").write_text(
    template.replace("__MODULES__", modules).replace("__SOUNDS__", json.dumps(sounds))
)
