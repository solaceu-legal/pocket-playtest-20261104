'use strict';

const { Mission, BOAT, clamp, angle, clear, distance, walkable } = require('./mission.js');
const { View } = require('./view.js');

const defaults = { forward: 0, strafe: 0, fire: false };
const movementKeys = new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space']);
const tapSlop = 7;
const direction = id => id?.startsWith('move-') ? id.slice(5) : '';
const HD_LIMITS = [
  { ratio: 3, side: 2800, pixels: 3600000, rayStep: .72 },
  { ratio: 2.65, side: 2400, pixels: 2700000, rayStep: .85 },
  { ratio: 2.3, side: 2050, pixels: 2000000, rayStep: 1 },
];
const STANDARD = { ratio: 1.55, side: 1100, pixels: 1250000, rayStep: 2 };

function renderSettings(w, h, dpr, high, tier) {
  const profile = high ? HD_LIMITS[tier] : STANDARD;
  const scale = Math.min(dpr || 1, profile.ratio, profile.side / Math.max(w, h),
    Math.sqrt(profile.pixels / (w * h)));
  return { scale, rayStep: profile.rayStep };
}

function createGame(adapter) {
  const ctx = adapter.canvas.getContext('2d');
  const view = new View(ctx, adapter.createSurface);
  const pressed = new Set();
  let sound = adapter.load('sound-enabled') !== false;
  const mission = new Mission((kind, value) => {
    if (kind === 'win') adapter.save('best', value);
    if (sound) adapter.sound(kind);
    if (kind === 'relay' || kind === 'relay-all' || kind === 'win') adapter.haptic();
  });
  mission.best = Number(adapter.load('best')) || 0;

  let overlay = '';
  let helpFrom = '';
  let touch = null;
  const moveTouches = new Map();
  let highQuality = adapter.load('quality') !== 'standard';
  let qualityTier = 0;
  let sampledFrames = 0;
  let slowFrames = 0;
  let warmupUntil = 0;
  let audioAmbience = false;
  let frame = null;
  let scale = 1;
  let elapsed = 0;
  let lastFrame = null;
  let hidden = false;
  let aimAt = -99;
  let lastRender = -99;
  let guide = false;
  let guidedObjective = null;

  const screen = () => overlay || mission.mode;
  const activeMoves = () => new Set(moveTouches.values());
  function syncAudio() {
    const next = sound && !hidden && screen() === 'play';
    if (next === audioAmbience) return;
    audioAmbience = next;
    adapter.ambience(next);
  }
  function clearControls() {
    touch = null;
    moveTouches.clear();
    pressed.clear();
  }

  function draw() {
    if (typeof ctx.setTransform === 'function') ctx.setTransform(scale, 0, 0, scale, 0, 0);
    view.draw(mission, elapsed, screen(), sound, adapter.reduced(), activeMoves());
  }

  function resize() {
    const { w, h, dpr, safe } = adapter.measure();
    const settings = renderSettings(w, h, dpr, highQuality, qualityTier);
    scale = settings.scale;
    adapter.canvas.width = Math.round(w * scale);
    adapter.canvas.height = Math.round(h * scale);
    if (typeof ctx.setTransform !== 'function') ctx.scale(scale, scale);
    view.resize(w, h, safe, highQuality, settings.rayStep);
    draw();
  }

  function action(id, x, y) {
    if (sound && id !== 'sound') adapter.sound('ui');
    if (id === 'deploy') {
      overlay = '';
      mission.deploy();
      sampledFrames = slowFrames = 0;
      warmupUntil = elapsed + 1.2;
      aimAt = -99;
      guide = false;
      guidedObjective = null;
    } else if (id === 'help') {
      helpFrom = overlay;
      overlay = 'help';
    } else if (id === 'close-help') {
      overlay = helpFrom;
    } else if (id === 'pause' || id === 'map') {
      overlay = id;
      clearControls();
    } else if (id === 'resume') {
      overlay = '';
    } else if (id === 'sound') {
      sound = !sound;
      adapter.save('sound-enabled', sound);
      adapter.setSound(sound);
      if (sound) { adapter.unlockSound(); adapter.sound('ui'); }
    } else if (id === 'quality') {
      highQuality = !highQuality;
      qualityTier = sampledFrames = slowFrames = 0;
      warmupUntil = elapsed + 1.2;
      adapter.save('quality', highQuality ? 'high' : 'standard');
      resize();
    } else if (id === 'use') {
      mission.use();
      guide = false;
      guidedObjective = null;
    } else if (id === 'stop') {
      mission.stop();
      guide = false;
      guidedObjective = null;
    } else if (id === 'restart') {
      overlay = '';
      mission.reset();
      mission.mode = 'title';
      guide = false;
      guidedObjective = null;
    } else if (id === 'map-point') {
      const { ox, oy, s } = view.mapSpace;
      let px = (x - ox) / s, py = (y - oy) / s;
      const objective = mission.relays.concat(mission.cutCount === 3 ? [BOAT] : [])
        .find(p => !p.cut && Math.hypot(px-p.x, py-p.y) < 1.8);
      if (objective) {
        const ring = Array.from({ length: 12 }, (_, index) => {
          const bearing = index * Math.PI / 6;
          return { x: objective.x + Math.cos(bearing) * 1.3, y: objective.y + Math.sin(bearing) * 1.3 };
        });
        const approach = ring.filter(point => walkable(point.x, point.y) && clear(point, objective))
          .sort((a,b) => distance(a,mission.player) - distance(b,mission.player))[0] || objective;
        px = approach.x; py = approach.y;
      }
      if (!walkable(px, py) && walkable(Math.floor(px)+.5, Math.floor(py)+.5)) {
        px = Math.floor(px)+.5; py = Math.floor(py)+.5;
      }
      overlay = '';
      if (mission.go(px, py)) { guide = true; guidedObjective = objective; aimAt = -99; }
    }
    syncAudio();
    draw();
  }

  function down(id, x, y) {
    if (hidden) return;
    if (sound) adapter.unlockSound();
    const button = view.hit(x,y)?.id;
    const moveKey = direction(button);
    if (screen() === 'play' && moveKey) {
      moveTouches.set(id, moveKey);
      mission.stop();
      guide = false;
      guidedObjective = null;
      draw();
      return;
    }
    if (touch) return;
    touch = { id, x, y, lastX: x, lastY: y, drag: false, button };
  }

  function move(id, x, y) {
    if (moveTouches.has(id)) {
      moveTouches.set(id, direction(view.hit(x,y)?.id));
      return;
    }
    if (!touch || touch.id !== id || touch.button || screen() !== 'play') return;
    if (!touch.drag && Math.hypot(x - touch.x, y - touch.y) < tapSlop) return;
    touch.drag = true;
    const sensitivity = clamp(400 / view.w, 0.8, 1.25);
    const player = mission.player;
    player.yaw = angle(player.yaw + (x - touch.lastX) * .0063 * sensitivity);
    player.pitch = clamp(player.pitch - (y - touch.lastY) * .0047 * sensitivity, -.46, .39);
    touch.lastX = x;
    touch.lastY = y;
    aimAt = elapsed;
  }

  function up(id, x, y, cancel = false) {
    if (moveTouches.delete(id)) {
      draw();
      return;
    }
    if (!touch || touch.id !== id) return;
    const before = touch;
    touch = null;
    if (cancel || before.drag || Math.hypot(x-before.x,y-before.y)>tapSlop*1.4) return;
    if (before.button && view.hit(x,y)?.id === before.button) action(before.button,x,y);
  }

  function key(code, down) {
    if (!down) { pressed.delete(code); return; }
    if (pressed.has(code)) return;
    pressed.add(code);
    if (sound) adapter.unlockSound();
    if (code === 'Escape') {
      if (screen() === 'help') action('close-help');
      else if (overlay) action('resume');
      else if (mission.mode === 'play') action('pause');
      return;
    }
    if (code === 'KeyM' && mission.mode === 'play') {
      if (!overlay || overlay === 'map') action(overlay ? 'resume' : 'map');
      return;
    }
    if (code === 'Enter') {
      if (screen() === 'title' || screen() === 'lost' || screen() === 'win') action('deploy');
      else if (screen() === 'pause' || screen() === 'map') action('resume');
      else if (screen() === 'help') action('close-help');
      else if (screen() === 'play') action('use');
    }
    if (code === 'KeyE' && screen() === 'play') action('use');
  }

  function adaptQuality(dt) {
    if (!highQuality || qualityTier >= HD_LIMITS.length - 1 || elapsed < warmupUntil || dt <= 0) return;
    sampledFrames++;
    if (dt > .025) slowFrames++;
    if (sampledFrames < 120) return;
    if (slowFrames / sampledFrames > .7) {
      qualityTier++;
      warmupUntil = elapsed + 1.2;
      resize();
    }
    sampledFrames = slowFrames = 0;
  }

  function tick(timestamp) {
    if (hidden) return;
    const now = Number.isFinite(timestamp) ? timestamp : Date.now();
    const dt = lastFrame === null ? 0 : clamp((now-lastFrame)/1000,0,.05);
    lastFrame = now;
    elapsed += dt;
    if (screen() === 'play') {
      adaptQuality(dt);
      const input = { ...defaults };
      if (pressed.size) {
        input.forward = Number(pressed.has('KeyW')) - Number(pressed.has('KeyS'));
        input.strafe = Number(pressed.has('KeyD')) - Number(pressed.has('KeyA'));
        input.fire = pressed.has('Space');
        const yaw = Number(pressed.has('ArrowRight')) - Number(pressed.has('ArrowLeft'));
        const pitch = Number(pressed.has('ArrowUp')) - Number(pressed.has('ArrowDown'));
        if (yaw || pitch) {
          mission.player.yaw = angle(mission.player.yaw + yaw*dt*1.8);
          mission.player.pitch = clamp(mission.player.pitch + pitch*dt*1.2,-.46,.39);
          aimAt = elapsed;
        }
        if (input.forward || input.strafe) { guide = false; guidedObjective = null; }
      }
      const moves = activeMoves();
      input.forward = clamp(input.forward + Number(moves.has('forward')) - Number(moves.has('back')), -1, 1);
      input.strafe = clamp(input.strafe + Number(moves.has('right')) - Number(moves.has('left')), -1, 1);
      const next = mission.path[0] || guidedObjective;
      if (guide && next && elapsed-aimAt>1.1 && !mission.target && !touch) {
        const p = mission.player;
        const heading = Math.atan2(next.y-p.y,next.x-p.x);
        p.yaw = angle(p.yaw + clamp(angle(heading-p.yaw),-dt*2.8,dt*2.8));
        p.pitch += (0-p.pitch)*Math.min(1,dt*2.2);
        if (!mission.path.length && Math.abs(angle(heading-p.yaw))<.07) guidedObjective = null;
      }
      mission.update(dt,input);
      if (mission.mode !== 'play') {
        clearControls();
        syncAudio();
      }
    }
    const rate = overlay || mission.mode !== 'play' ? 30 : highQuality ? 60 : 40;
    if (elapsed-lastRender >= 1/rate - .002) {
      draw();
      lastRender = elapsed;
    }
    frame = adapter.request(tick);
  }

  function hide() {
    if (hidden) return;
    if (screen() === 'play') overlay = 'pause';
    hidden = true;
    clearControls();
    syncAudio();
    adapter.setSound(false);
    if (frame !== null) adapter.cancel(frame);
    frame = null;
  }

  function show() {
    if (!hidden) return;
    hidden = false;
    adapter.setSound(sound);
    syncAudio();
    lastFrame = null;
    resize();
    frame = adapter.request(tick);
  }

  adapter.setSound(sound);
  resize();
  frame = adapter.request(tick);

  return { down, move, up, key, resize, hide, show, cancelTouches: clearControls };
}

module.exports = { createGame, movementKeys, renderSettings };
