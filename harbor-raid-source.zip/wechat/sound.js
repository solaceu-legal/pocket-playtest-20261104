'use strict';

const gains = {
  shot: .67, step: .52, rain: .31, ui: .64, hurt: .53, hit: .28,
  alert: .43, relay: .61, 'relay-all': .6, win: .62, death: .53,
  'reload-out': .62, 'reload-in': .62, 'reload-bolt': .65,
  'gull-fire': .37, 'hound-fire': .39, 'gull-kill': .48, 'hound-kill': .51,
};

function createSamplePicker() {
  const variants = { shot: 0, step: 0 };
  return kind => {
    if (!(kind in gains)) return null;
    const variant = variants[kind];
    if (variant === undefined) return { file: kind, gain: gains[kind], group: 'event' };
    variants[kind] = (variant + 1) % 4;
    return { file: kind + '-' + variant, gain: gains[kind], group: kind };
  };
}
module.exports = { createSamplePicker };
