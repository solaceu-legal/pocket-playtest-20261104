'use strict';

const { createGame } = require('./runtime.js');
const canvas = wx.createCanvas();
const { createSamplePicker } = require('./sound.js');
const pickSample = createSamplePicker();
const groups = { shot: 3, step: 2, event: 4 };
const pools = {};
let enabled = true;
let background = null;
const raf = typeof requestAnimationFrame === 'function' ? requestAnimationFrame : cb => setTimeout(() => cb(Date.now()), 17);
const caf = typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame : clearTimeout;

function createPlayer() {
  const player = wx.createInnerAudioContext();
  if (typeof player.onError === 'function') player.onError(error => console.warn('Harbor Raid audio', error.errMsg));
  return player;
}

function playSound(kind) {
  if (!enabled || typeof wx.createInnerAudioContext !== 'function') return;
  const sample = pickSample(kind);
  if (!sample) return;
  try {
    const pool = pools[sample.group] || (pools[sample.group] = { next: 0, players: [] });
    const slot = pool.next++ % groups[sample.group];
    const player = pool.players[slot] || (pool.players[slot] = createPlayer());
    player.stop();
    player.src = `audio/${sample.file}.mp3`;
    player.volume = sample.gain;
    player.play();
  } catch (error) {
    console.warn('Harbor Raid audio', error.message);
  }
}

function ambience(on) {
  if (typeof wx.createInnerAudioContext !== 'function') return;
  try {
    if (on && !background) {
      background = createPlayer();
      background.src = 'audio/rain.mp3';
      background.loop = true;
      background.volume = pickSample('rain').gain;
    }
    if (!background) return;
    if (on) background.play();
    else background.pause();
  } catch (error) {
    console.warn('Harbor Raid ambience', error.message);
  }
}

function setSound(on) {
  enabled = on;
  if (on) return;
  ambience(false);
  for (const pool of Object.values(pools)) {
    for (const player of pool.players) player.stop();
  }
}

const game = createGame({
  canvas,
  createSurface(w,h) {
    if (typeof wx.createOffscreenCanvas === 'function') {
      return wx.createOffscreenCanvas({ type:'2d', width:w, height:h });
    }
    const offscreen = wx.createCanvas();
    offscreen.width = w;
    offscreen.height = h;
    return offscreen;
  },
  measure() {
    const info = typeof wx.getWindowInfo === 'function' ? wx.getWindowInfo() : wx.getSystemInfoSync();
    const w = info.windowWidth, h = info.windowHeight;
    const area = info.safeArea;
    const inset = area ? Math.max(0,area.top) : info.statusBarHeight || 0;
    let top = inset;
    if (typeof wx.getMenuButtonBoundingClientRect === 'function') {
      try {
        const menu = wx.getMenuButtonBoundingClientRect();
        if (menu && menu.bottom > 0 && menu.bottom < h * .16) top = Math.max(inset,menu.bottom);
      } catch (_) {}
    }
    return {
      w, h, dpr: info.pixelRatio,
      safe: {
        top, left:area?Math.max(0,area.left):0, right:area?Math.max(0,w-area.right):0,
        bottom:area?Math.max(0,h-area.bottom):0,
      },
    };
  },
  request: raf,
  cancel: caf,
  reduced: () => false,
  load(key) { try { return wx.getStorageSync(`dock04-${key}`); } catch (_) { return null; } },
  save(key,value) { try { wx.setStorageSync(`dock04-${key}`,value); } catch (_) {} },
  sound: playSound,
  unlockSound() {},
  ambience,
  setSound,
  haptic() { if (typeof wx.vibrateShort === 'function') wx.vibrateShort({ type:'light', fail() {} }); },
});

function dispatch(event, handler, cancel) {
  for (const point of event.changedTouches || []) {
    handler(point.identifier,point.clientX ?? point.pageX,point.clientY ?? point.pageY,cancel);
  }
}
wx.onTouchStart(event => dispatch(event,game.down));
wx.onTouchMove(event => dispatch(event,game.move));
wx.onTouchEnd(event => dispatch(event,game.up));
wx.onTouchCancel(event => {
  if (event.changedTouches?.length) dispatch(event,game.up,true);
  else game.cancelTouches();
});
if (typeof wx.onWindowResize === 'function') wx.onWindowResize(game.resize);
wx.onHide(game.hide);
wx.onShow(game.show);
