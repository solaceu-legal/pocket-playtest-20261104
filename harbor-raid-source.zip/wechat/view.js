'use strict';

const { WIDTH, HEIGHT, BOAT, TYPES, CUT_TIME, MAGAZINE, clamp, angle, distance, ray, materialAt } = require('./mission.js');

const C = {
  text: '#f3f2e9', muted: '#b9beb3', dim: '#8a938c', mint: '#d8f990',
  orange: '#ffb45f', red: '#ff765a', line: 'rgba(216,230,208,.22)', plate: 'rgba(13,22,21,.86)',
};
const WALLS = [
  null, ['#815045', '#ae6e50', '#462a25', 3.45], ['#46574e', '#718372', '#29362e', 3.25],
  ['#52626b', '#75888b', '#303f43', 3.75], ['#4c5049', '#6a7065', '#292e2d', 4.1],
  ['#74643f', '#9c8552', '#4b3a27', 1.45], ['#3f5554', '#688380', '#293d3d', 0.65],
];
const FONT = 'sans-serif';
const MONO = 'monospace';
const EYE = 1.55;

function shape(ctx, points, fill, stroke, lineWidth = 1) {
  ctx.beginPath();
  points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.closePath();
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lineWidth; ctx.strokeStyle = stroke; ctx.stroke(); }
}
function line(ctx, x, y, toX, toY, color, width = 1) {
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(toX, toY);
  ctx.lineWidth = width; ctx.strokeStyle = color; ctx.stroke();
}
function rect(ctx, x, y, w, h, fill) {
  if (w <= 0 || h <= 0) return;
  ctx.fillStyle = fill; ctx.fillRect(x, y, w, h);
}
function label(ctx, text, x, y, opts = {}) {
  ctx.fillStyle = opts.color || C.text;
  ctx.font = `${opts.weight || 500} ${opts.size || 12}px ${opts.mono ? MONO : FONT}`;
  ctx.textAlign = opts.align || 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(text), x, y, opts.max || 2000);
}
function gradient(ctx, x, y, toX, toY, stops) {
  const result = ctx.createLinearGradient(x, y, toX, toY);
  stops.forEach(([position, color]) => result.addColorStop(position, color));
  return result;
}
function circle(ctx, x, y, r, color, stroke, width = 1) {
  ctx.beginPath(); ctx.arc(x, y, r, 0, 2 * Math.PI);
  if (color) { ctx.fillStyle = color; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = width; ctx.stroke(); }
}
function diamond(ctx, x, y, r, fill, stroke) {
  shape(ctx, [[x, y-r], [x+r, y], [x, y+r], [x-r, y]], fill, stroke);
}
function brackets(ctx, x, y, w, h, color, n = 7) {
  for (const [cx, cy, sx, sy] of [[x,y,1,1], [x+w,y,-1,1], [x,y+h,1,-1], [x+w,y+h,-1,-1]]) {
    line(ctx, cx, cy, cx + sx*n, cy, color);
    line(ctx, cx, cy, cx, cy + sy*n, color);
  }
}
function formatTime(s) {
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
}
function seeded(seed) {
  let state = seed;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function wallTexture(surface, id, variant) {
  const ctx = surface.getContext('2d'), w = 64, h = 128;
  const [base, light, dark] = WALLS[id], rng = seeded(id * 71 + variant * 173);
  ctx.scale(surface.width / w, surface.height / h);
  rect(ctx, 0, 0, w, h, gradient(ctx, 0, 0, 0, h, [[0, light], [0.2, base], [1, dark]]));
  for (let x = 0; x < w; x += id === 4 ? 16 : 10) {
    rect(ctx, x, 6, 3, h - 12, 'rgba(0,0,0,.25)');
    rect(ctx, x+3, 6, 1, h - 12, 'rgba(255,233,203,.18)');
    rect(ctx, x+5, 7, 2, h - 16, 'rgba(0,0,0,.07)');
  }
  for (let i = 0; i < 180; i++) {
    const x = rng()*w, y = rng()*h;
    rect(ctx, x, y, 1+rng()*5, 1+rng()*6, i % 2 ? 'rgba(225,174,123,.12)' : 'rgba(21,24,22,.17)');
  }
  for (let i = 0; i < 310; i++) {
    const x = rng() * w, y = 4 + rng() * 118;
    const stain = i % 3 ? 'rgba(31,25,21,.19)' : 'rgba(215,147,85,.29)';
    rect(ctx, x, y, .28 + rng() * .55, .6 + rng() * 16, stain);
  }
  for (const y of [0, 116, 123]) {
    rect(ctx, 0, y, w, 6, dark);
    rect(ctx, 0, y+2, w, 1, light);
  }
  if (id < 4 && variant === 0) {
    label(ctx, ['','JI MAO','NORTH','04'][id], 32, 34, { size: 10, color: '#d9cfab', align: 'center', mono: true, weight: 800 });
    rect(ctx, 9, 42, 46, 1, 'rgba(219,211,167,.42)');
  }
  if (id <= 3) {
    for (let x=8; x<w; x+=10) {
      rect(ctx,x,9,.35,104,'rgba(222,192,151,.24)');
      rect(ctx,x+.65,9,.32,104,'rgba(23,24,21,.24)');
    }
    for (const y of [4,119]) {
      for (let x=5; x<w; x+=12) circle(ctx,x,y,.46,light,dark,.23);
    }
    const edge = variant === 0 ? 2 : 60;
    rect(ctx,edge,3,2,119,'rgba(27,28,24,.42)');
    rect(ctx,edge+2,4,.7,116,'rgba(220,194,148,.28)');
    for (const y of [8,111]) circle(ctx,edge+1,y,1.25,light,'rgba(23,26,22,.72)',.5);
  }
  if (id === 4 && variant === 1) {
    rect(ctx, 4, 17, 56, 29, '#292f2d');
    for (let i = 0; i < 4; i++) rect(ctx, 7+i*13, 20, 10, 22, i === 2 ? '#6c7260' : '#3b4b43');
  }
  if (id >= 5) {
    rect(ctx, 0, 8, w, 18, '#242926');
    for (let i = -16; i < 68; i += 13) shape(ctx, [[i,26],[i+8,26],[i+20,8],[i+12,8]], '#b18c4c');
  }
}

function unitSprite(surface, kind, hot) {
  const ctx = surface.getContext('2d');
  ctx.scale(surface.width / 128, surface.height / 90);
  const glow = hot ? '#ffead0' : '#ff6846';
  const metal = hot ? '#c98c64' : '#7a8377';
  const dark = '#222a2a', edge = '#c4b89e';
  const g = ctx.createRadialGradient(64, 45, 0, 64, 45, hot ? 52 : 28);
  g.addColorStop(0, hot ? 'rgba(255,111,60,.63)' : 'rgba(255,105,62,.27)');
  g.addColorStop(1, 'rgba(255,105,62,0)');
  circle(ctx,64,45,hot ? 52 : 28,g);
  if (kind === 'gull') {
    shape(ctx, [[4,33],[25,29],[51,39],[77,39],[104,29],[124,33],[112,49],[87,52],[71,60],[56,60],[41,52],[16,49]], dark, '#141a19', 2);
    shape(ctx, [[7,33],[28,32],[53,42],[48,49],[27,44],[14,43]], metal, '#a39f84');
    shape(ctx, [[121,33],[100,32],[75,42],[80,49],[101,44],[114,43]], metal, '#a39f84');
    for (const x of [18, 27, 92, 101]) rect(ctx,x,39,9,2,'#383e3b');
    shape(ctx, [[53,38],[64,28],[75,38],[78,49],[70,59],[57,59],[50,49]], '#4b5045', edge, 1.5);
    shape(ctx, [[53,51],[59,47],[69,47],[75,51],[69,58],[59,58]], '#191b1a');
    circle(ctx,64,47,hot ? 8 : 5,'#a44032', '#f39160', 2);
    circle(ctx,64,47,hot ? 4 : 2.7,glow);
    rect(ctx,17,45,9,2,'#f99651'); rect(ctx,102,45,9,2,'#f99651');
  } else {
    shape(ctx, [[20,59],[31,37],[44,42],[39,61],[33,73],[36,87],[20,87],[16,78]], dark, '#1a1c1a', 2);
    shape(ctx, [[108,59],[97,37],[84,42],[89,61],[95,73],[92,87],[108,87],[112,78]], dark, '#1a1c1a', 2);
    shape(ctx, [[28,39],[43,30],[85,30],[100,39],[101,53],[87,64],[41,64],[27,53]], '#424b43', '#91927d', 2);
    shape(ctx, [[39,52],[47,36],[58,42],[70,42],[81,36],[89,52],[82,70],[70,75],[58,75],[46,70]], metal, dark, 2);
    shape(ctx, [[49,55],[57,49],[71,49],[79,55],[75,62],[53,62]], dark);
    line(ctx,53,56,60,58,glow,2.5); line(ctx,68,58,75,56,glow,2.5);
    rect(ctx,59,66,10,4,'#252724');
    for (const x of [26,101]) circle(ctx,x,56,4,'#ab8260','#343b36',2);
  }
}

function relaySprite(surface, cut) {
  const ctx = surface.getContext('2d');
  ctx.scale(surface.width / 96, surface.height / 116);
  const signal = cut ? '#d8f990' : '#ff9c53';
  const halo = ctx.createRadialGradient(48,39,0,48,39,40);
  halo.addColorStop(0, cut ? 'rgba(190,255,125,.25)' : 'rgba(255,140,64,.43)');
  halo.addColorStop(1, 'rgba(255,140,64,0)');
  circle(ctx,48,39,40,halo);
  shape(ctx, [[16,107],[30,97],[75,97],[83,107],[73,115],[27,115]], '#222c27', '#4b5e54', 2);
  shape(ctx, [[24,56],[37,47],[77,49],[76,105],[27,105]], '#252e2a', '#161c1b', 3);
  shape(ctx, [[27,56],[64,56],[64,104],[27,104]], '#596555', '#86917b', 2);
  shape(ctx, [[64,56],[77,49],[76,105],[64,104]], '#333f38', '#536451', 1.5);
  rect(ctx,34,62,23,17,'#242e27'); rect(ctx,37,65,17,10,signal);
  rect(ctx,39,67,12,1,'#252c24'); rect(ctx,39,71,7,1,'#252c24');
  for (let i=0;i<5;i++) rect(ctx,34,85+i*3,23,1,'#2e3931');
  line(ctx,57,49,57,15,'#191e1c',4); line(ctx,57,15,65,8,'#777e69',2);
  circle(ctx,65,8,3,signal);
}

function boatSprite(surface) {
  const ctx = surface.getContext('2d');
  ctx.scale(surface.width / 140, surface.height / 122);
  shape(ctx, [[4,95],[34,102],[110,102],[136,91],[133,106],[120,119],[28,119],[13,111]], '#465c52', '#141f1d', 2);
  shape(ctx, [[27,101],[39,87],[100,87],[120,98],[104,107],[39,107]], '#838879', '#acaa8c', 1);
  shape(ctx, [[52,91],[54,60],[88,60],[103,91]], '#b6ad93', '#323f36', 2);
  shape(ctx, [[59,67],[84,67],[93,80],[59,80]], '#344b47', '#788a76', 1);
  line(ctx,68,61,68,32,'#a7b19a',2); line(ctx,56,39,86,39,'#a7b19a',2);
  circle(ctx,68,32,4,'#d8f990');
  line(ctx,19,111,126,111,'#e3aa5a',2);
}

class View {
  constructor(ctx, createSurface) {
    this.ctx = ctx;
    this.buttons = [];
    this.textures = WALLS.map((material, id) => material && [0,1].map(variant => {
      const surface = createSurface(256,512);
      wallTexture(surface,id,variant);
      return surface;
    }));
    this.sprites = {};
    for (const kind of ['gull','hound','relay','boat']) {
      this.sprites[kind] = [false,true].map(hot => {
        const surface = createSurface(kind === 'relay' ? 288 : kind === 'boat' ? 420 : 384, kind === 'relay' ? 348 : kind === 'boat' ? 366 : 270);
        if (kind === 'relay') relaySprite(surface,hot);
        else if (kind === 'boat') boatSprite(surface);
        else unitSprite(surface,kind,hot);
        return surface;
      });
    }
    const rng = seeded(1130);
    this.rain = Array.from({length:52}, () => [rng(),rng(),rng(),rng()]);
    this.grain = Array.from({length:100}, () => [rng(),rng(),rng()]);
    this.puddles = [];
    for (let y=2; y<HEIGHT-1; y+=2) {
      for (let x=2; x<WIDTH-1; x+=2) {
        const px=x+rng(), py=y+rng();
        if (materialAt(Math.floor(px),Math.floor(py))) continue;
        this.puddles.push([px,py,.2+rng()*.75,.18+rng()*.5,rng()]);
      }
    }
    this.cranes = [
      [11,-4,8,11], [22,-2,10,9], [31,3,8,10], [38,12,10,12], [40,20,7,9], [35,34,9,11],
    ];
    this.gantry = [
      [22,1,5], [25,1,6.2], [30,2,5.2], [32,2,6.5], [34,3,4.8], [39,5,5], [40,9,4], [42,15,5], [41,24,6],
    ];
  }

  resize(w, h, safe, highQuality, rayStep) {
    this.w = w; this.h = h;
    this.safe = safe;
    this.left = safe.left + 14;
    this.right = w - safe.right - 14;
    this.top = safe.top + 12;
    this.bottom = h - safe.bottom - 13;
    const radius = h < 525 ? 43 : Math.round(clamp((this.right - this.left) * .16, 46, 59));
    this.stickLayout = {
      x: this.left + radius, y: this.bottom - 49 - radius, radius, travel: radius - 18,
    };
    this.focal = Math.min(w * 0.86, h * 0.92);
    this.highQuality = highQuality;
    this.stride = Math.max(rayStep, w / (highQuality ? 840 : 500));
    this.depth = new Float32Array(Math.ceil(w / this.stride));
  }

  camera(game, clock) {
    const p = game.player;
    this.px = p.x; this.py = p.y;
    const yaw = p.yaw + (game.mode === 'title' ? Math.sin(clock*0.12)*0.055 : 0);
    this.yaw = yaw;
    this.fx = Math.cos(yaw); this.fy = Math.sin(yaw);
    this.rx = -this.fy; this.ry = this.fx;
    const tilt = Math.tan(p.pitch) * this.focal;
    this.horizon = this.h * 0.45 + tilt + Math.sin(game.walk * 2) * game.motion * 2.8;
  }

  project(x, y, z) {
    const dx = x - this.px, dy = y - this.py;
    const depth = dx * this.fx + dy * this.fy;
    if (depth <= 0.05) return null;
    const across = dx * this.rx + dy * this.ry;
    return { x: this.w / 2 + across * this.focal / depth, y: this.horizon + (EYE-z) * this.focal / depth, depth };
  }

  sky() {
    const ctx = this.ctx, w = this.w, h = this.h;
    const horizon = clamp(this.horizon, 50, h-40);
    rect(ctx,0,0,w,horizon+2,gradient(ctx,0,0,0,horizon,[[0,'#18282e'],[0.52,'#426260'],[0.8,'#809081'],[1,'#b7a47d']]));
    const sunAngle = angle(-0.68-this.yaw);
    const sunX = w/2 + Math.tan(clamp(sunAngle,-1.3,1.3))*this.focal;
    const sunY = this.horizon - this.focal * 0.15;
    if (Math.abs(sunAngle)<1.1) {
      const glow = ctx.createRadialGradient(sunX,sunY,1,sunX,sunY,this.focal*0.48);
      glow.addColorStop(0,'rgba(255,207,129,.79)'); glow.addColorStop(0.23,'rgba(241,174,103,.32)');
      glow.addColorStop(1,'rgba(255,180,100,0)');
      circle(ctx,sunX,sunY,this.focal*0.48,glow);
      circle(ctx,sunX,sunY,this.focal*0.033,'#eadbb0');
    }
    for (let i=0;i<10;i++) {
      const y = this.horizon-(16+i*i*2.4);
      const offset = Math.sin(i*31.7+this.yaw*0.5)*w*0.36;
      rect(ctx,offset,y,w*1.5,2+(i%3)*2, i%3 ? 'rgba(32,49,50,.16)' : 'rgba(209,191,145,.11)');
    }
    const skyline = this.gantry;
    for (const [x,y,z] of skyline) {
      const at = this.project(x,y,z);
      if (!at || at.depth < 5) continue;
      const ww = this.focal * 1.8 / at.depth;
      rect(ctx,at.x-ww/2,at.y,ww,this.horizon-at.y+22,'#475953');
      for (let i=0;i<3;i++) rect(ctx,at.x-ww*.27,at.y+5+i*6,ww*.24,1,'rgba(214,177,108,.25)');
    }
    for (const [x,y,z,arm] of this.cranes) {
      const near = this.project(x,y,0), head = this.project(x,y,z), far = this.project(x-arm,y,z);
      const foot = this.project(x+1.1,y,0), brace = this.project(x,y,z*.63), apex = this.project(x,y,z+1.25);
      if (!near || !head || !far || !foot || !brace || !apex || near.depth < 3 || far.depth < 3) continue;
      const color = '#374743', thick = clamp(this.focal/near.depth*.16,1,4);
      line(ctx,near.x,near.y,head.x,head.y,color,thick);
      line(ctx,foot.x,foot.y,head.x,head.y,color,thick);
      line(ctx,head.x,head.y,far.x,far.y,color,thick*1.4);
      line(ctx,apex.x,apex.y,far.x,far.y,color,thick*.58);
      line(ctx,apex.x,apex.y,brace.x,brace.y,color,thick*.8);
      const cable = this.project(x-arm,y,z*.45);
      if (cable) line(ctx,far.x,far.y,cable.x,cable.y,'#4e5345',1);
      for (let j=1;j<7;j++) {
        const at = j/7;
        const xx = head.x+(far.x-head.x)*at, yy = head.y+(far.y-head.y)*at;
        line(ctx,xx,yy,xx+4,yy-3,color,0.8);
      }
      circle(ctx,apex.x,apex.y,1.5,'#e9a15f');
    }
  }

  ground() {
    const ctx = this.ctx, w = this.w, h = this.h;
    const top = clamp(this.horizon,0,h-1);
    rect(ctx,0,top,w,h-top,gradient(ctx,0,top,0,h,[[0,'#727e70'],[.15,'#4a574c'],[.52,'#303d34'],[1,'#1d2724']]));
    const near = this.py > 23 || this.px > 31;
    const center = this.horizon;
    if (this.highQuality) {
      for (let tile=2; tile<Math.max(WIDTH,HEIGHT); tile+=2) {
        if (tile<WIDTH) this.groundLine(tile,1,tile,HEIGHT-1,'rgba(12,24,21,.34)');
        if (tile<HEIGHT) this.groundLine(1,tile,WIDTH-1,tile,'rgba(12,24,21,.34)');
      }
      for (const [x,y,rw,rh,seed] of this.puddles) {
        const depth=(x-this.px)*this.fx+(y-this.py)*this.fy;
        if (depth<1.25 || depth>22 || Math.abs((x-this.px)*this.rx+(y-this.py)*this.ry)>depth*.76+1) continue;
        const points=[[-rw,-rh*.2],[-rw*.6,-rh*.75],[rw*.26,-rh],[rw,-rh*.25],[rw*.66,rh*.53],[-rw*.3,rh*.8]]
          .map(([dx,dy])=>this.project(x+dx,y+dy,.008));
        if (!points.every(Boolean)) continue;
        shape(ctx,points.map(at=>[at.x,at.y]),seed>.48?'rgba(113,146,135,.28)':'rgba(91,121,110,.24)');
        line(ctx,points[1].x,points[1].y,points[3].x,points[3].y,'rgba(178,186,143,.16)',1);
        if (depth<9) this.groundLine(x-rw,y+rh,x+rw*.42,y+rh*.94,'rgba(11,25,20,.27)');
      }
    } else {
      for (let d=2;d<38;d+=d<8?1:3) {
        const y=center+EYE*this.focal/d;
        if(y>=top && y<=h) rect(ctx,0,y,w,1,'rgba(11,22,22,.17)');
      }
    }
    for (const [gx, gy, gz] of this.grain) {
      const y=top+gy*(h-top);
      rect(ctx,gx*w,y,1+gz*3,1,gz<.5?'rgba(14,25,23,.14)':'rgba(186,196,157,.1)');
    }
    const laneLines = [[2,24.6,33,24.6],[2,25.1,33,25.1],[10.5,13,10.5,19],[24.1,15,24.1,24],[31.7,15,31.7,28]];
    for (const [ax,ay,bx,by] of laneLines) {
      for (let i=0;i<12;i++) {
        const from=i/12, to=(i+.82)/12;
        const a=this.project(ax+(bx-ax)*from,ay+(by-ay)*from,0.01);
        const b=this.project(ax+(bx-ax)*to,ay+(by-ay)*to,0.01);
        if (!a || !b || a.depth<.25 || b.depth<.25) continue;
        line(ctx,a.x,a.y,b.x,b.y,near?'rgba(212,174,91,.4)':'rgba(205,173,91,.29)',clamp(this.focal/a.depth*.025,.5,3));
      }
    }
  }

  groundLine(ax,ay,bx,by,color) {
    const near=.45;
    const ad=(ax-this.px)*this.fx+(ay-this.py)*this.fy;
    const bd=(bx-this.px)*this.fx+(by-this.py)*this.fy;
    if (ad<near && bd<near) return;
    if (ad<near) { const t=(near-ad)/(bd-ad); ax+=(bx-ax)*t; ay+=(by-ay)*t; }
    if (bd<near) { const t=(near-bd)/(ad-bd); bx+=(ax-bx)*t; by+=(ay-by)*t; }
    const a=this.project(ax,ay,.004), b=this.project(bx,by,.004);
    if (!a || !b || (a.x<0 && b.x<0) || (a.x>this.w && b.x>this.w)) return;
    line(this.ctx,a.x,a.y,b.x,b.y,color,clamp(this.focal/Math.min(a.depth,b.depth)*.015,.5,2));
  }

  wallColumn(hit,x,dx,dy) {
    const ctx=this.ctx, f=this.focal;
    const d=Math.max(.06,hit.depth), height=WALLS[hit.material][3]*f/d;
    const end=this.horizon+EYE*f/d, top=end-height;
    const drawTop=Math.max(0,top), drawEnd=Math.min(this.h,end), drawH=drawEnd-drawTop;
    if(drawH<=0)return;
    const texture=this.textures[hit.material][(hit.mx*3+hit.my*5)&1];
    const sy=(drawTop-top)*texture.height/height, sh=drawH*texture.height/height;
    const reverse=hit.side ? dy>0 : dx<0;
    const u=(reverse ? 1-hit.u : hit.u)*texture.width;
    ctx.drawImage(texture,Math.min(texture.width-1,Math.floor(u)),sy,1,sh,x,drawTop,this.stride+.1,drawH+.12);
    const fog=clamp(d/59+(hit.side?.16:0),0,.7);
    rect(ctx,x,drawTop,this.stride+.1,drawH,`rgba(49,66,61,${fog})`);
    if(this.highQuality) {
      const edge=clamp(2.4/d,.4,2.5);
      rect(ctx,x,top,this.stride+.1,edge,'rgba(225,208,167,.24)');
      rect(ctx,x,end-edge,this.stride+.1,edge,'rgba(6,14,13,.46)');
    }
  }

  walls() {
    const f=this.focal;
    for (let i=0;i<this.depth.length;i++) {
      const x=i*this.stride, plane=(x+this.stride/2-this.w/2)/f;
      const dx=this.fx+this.rx*plane, dy=this.fy+this.ry*plane;
      const hit=ray(this.px,this.py,dx,dy);
      this.depth[i]=hit.depth;
      if (this.highQuality && hit.material===5) {
        this.wallColumn(ray(this.px,this.py,dx,dy,true),x,dx,dy);
        const z=WALLS[5][3];
        const top=this.horizon+(EYE-z)*f/Math.max(.06,hit.depth);
        const end=this.horizon+(EYE-z)*f/(hit.depth+.75);
        rect(this.ctx,x,end,this.stride+.1,top-end,'#8a805e');
      }
      this.wallColumn(hit,x,dx,dy);
    }
  }

  visibleAt(at) {
    return at.x >= 0 && at.x < this.w && at.depth < (this.depth[Math.floor(at.x / this.stride)] ?? Infinity)+0.08;
  }

  billboard(image, at, worldWidth, worldHeight, alpha=1) {
    const ctx=this.ctx, w=worldWidth*this.focal/at.depth, h=worldHeight*this.focal/at.depth;
    const x=at.x-w/2, y=at.y-h/2;
    if (x>this.w || x+w<0 || y>this.h || y+h<0 || w<1) return;
    const begin=Math.max(0,Math.floor(x/this.stride));
    const end=Math.min(this.depth.length,Math.ceil((x+w)/this.stride));
    ctx.globalAlpha=alpha;
    let visibleStart=-1;
    for (let i=begin;i<=end;i++) {
      if (i<end && at.depth < this.depth[i]+.08) {
        if (visibleStart<0) visibleStart=i;
      } else if (visibleStart>=0) {
        const l=Math.max(x,visibleStart*this.stride), r=Math.min(x+w,i*this.stride);
        if (r>l) ctx.drawImage(image,(l-x)*image.width/w,0,(r-l)*image.width/w,image.height,l,y,r-l,h);
        visibleStart=-1;
      }
    }
    ctx.globalAlpha=1;
  }

  worldObjects(game) {
    const ctx=this.ctx, items=[];
    for (const relay of game.relays) {
      const at=this.project(relay.x,relay.y,1.01);
      if (at) items.push({ at, image:this.sprites.relay[+relay.cut], w:1.57, h:1.98 });
    }
    const boat=this.project(BOAT.x,BOAT.y,1.03);
    if (boat) items.push({ at:boat, image:this.sprites.boat[0], w:3.05, h:2.65 });
    for (const unit of game.units) {
      const gull=unit.type==='gull';
      const z=TYPES[unit.type].height+(gull?Math.sin(game.time*4+unit.phase)*.15:0);
      const at=this.project(unit.x,unit.y,z);
      if (at) items.push({ at, image:this.sprites[unit.type][+(unit.wind>0 || unit.hit>0)], w:gull?1.54:1.58, h:gull?1.08:1.15, unit });
    }
    items.sort((a,b)=>b.at.depth-a.at.depth);
    for (const item of items) {
      const { at, unit }=item;
      if (this.highQuality && this.visibleAt(at)) {
        const ground=this.horizon+EYE*this.focal/at.depth;
        const shadow=clamp(item.w*this.focal/at.depth*.37,2,48);
        ctx.save();
        ctx.translate(at.x,ground);
        ctx.scale(1,.28);
        circle(ctx,0,0,shadow,unit?.type==='gull'?'rgba(10,21,18,.24)':'rgba(10,21,18,.44)');
        ctx.restore();
      }
      this.billboard(item.image,at,item.w,item.h,clamp(1-at.depth*.014,.55,1));
      if (!unit || !this.visibleAt(at) || at.depth>15 || !unit.alert) continue;
      const y=at.y-item.h*this.focal/at.depth*.28-8;
      const width=clamp(86/at.depth,15,42);
      rect(ctx,at.x-width/2,y,width,3,'rgba(10,20,18,.8)');
      rect(ctx,at.x-width/2,y,width*unit.hp/unit.max,2,unit.wind>0?'#ffe1a2':C.orange);
      if (unit.wind>0) diamond(ctx,at.x,y-7,3.5,C.red);
    }
    for (const bolt of game.bolts) {
      const at=this.project(bolt.x,bolt.y,bolt.height);
      if (!at || !this.visibleAt(at)) continue;
      const r=clamp(22/at.depth,2,9);
      circle(ctx,at.x,at.y,r*2,'rgba(255,112,48,.27)');
      circle(ctx,at.x,at.y,r,'#ffbd7c');
      circle(ctx,at.x,at.y,r*.45,'#fff2b9');
    }
    for (const effect of game.effects) {
      const at=this.project(effect.x,effect.y,effect.height);
      if (!at || !this.visibleAt(at)) continue;
      const t=(effect.end-game.time)*2, r=clamp(130/at.depth,5,47);
      ctx.globalAlpha=t;
      circle(ctx,at.x,at.y,r*(1.1-t*.5),'rgba(255,125,51,.45)');
      for (let i=0;i<9;i++) {
        const a=i*2.39, size=r*(1.1-t);
        line(ctx,at.x+Math.cos(a)*size*.35,at.y+Math.sin(a)*size*.35,at.x+Math.cos(a)*size,at.y+Math.sin(a)*size,'#ffc275',1.5);
      }
      ctx.globalAlpha=1;
    }
    if (game.destination) {
      const at=this.project(game.destination.x,game.destination.y,.025);
      if (at && this.visibleAt(at)) {
        const r=clamp(74/at.depth,6,21);
        shape(ctx,[[at.x,at.y-r*.38],[at.x+r,at.y],[at.x,at.y+r*.38],[at.x-r,at.y]],'rgba(216,249,144,.13)',C.mint);
      }
    }
  }

  weather(clock, reduced) {
    const ctx=this.ctx,w=this.w,h=this.h;
    ctx.beginPath();
    for (let i=0;i<(reduced?20:this.rain.length);i++) {
      const [x,y,s,l]=this.rain[i];
      const a=((x+(clock*.06*(1+s)))%1)*w, b=((y+clock*(.47+s*.26))%1)*h;
      ctx.moveTo(a,b);ctx.lineTo(a+2+l*4,b+7+l*18);
    }
    ctx.strokeStyle='rgba(188,210,190,.23)';ctx.lineWidth=0.72;ctx.stroke();
    const v=ctx.createRadialGradient(w*.51,h*.45,Math.min(w,h)*.18,w*.51,h*.45,Math.max(w,h)*.64);
    v.addColorStop(0,'rgba(5,15,15,0)');v.addColorStop(1,'rgba(5,15,15,.67)');
    rect(ctx,0,0,w,h,v);
  }

  weapon(game) {
    const ctx=this.ctx, w=this.w, h=this.h;
    const size=clamp(Math.min(w,h)*.42,116,240);
    const bob=game.motion*Math.sin(game.walk)*6;
    const reload=game.reload?Math.sin(game.reload/1.26*Math.PI)*size*.32:0;
    ctx.save();
    ctx.translate(w*.5+size*.18+bob,h-size*.92+reload+game.flash*70);
    ctx.scale(size/180,size/180);
    shape(ctx,[[-8,151],[-17,115],[23,79],[64,87],[101,110],[123,156],[142,187],[-19,187]],'#232e28','#111b19',3);
    shape(ctx,[[-20,168],[-13,137],[13,118],[34,124],[35,156],[14,188],[-29,190]],'#3b493b','#1f2921',2);
    shape(ctx,[[48,100],[48,61],[38,52],[37,27],[42,23],[59,24],[66,47],[79,64],[89,111],[115,160],[76,189],[30,184],[17,139]],'#232d2b','#101716',3);
    shape(ctx,[[37,31],[43,21],[56,20],[63,26],[65,57],[72,63],[80,111],[97,154],[67,168],[41,154],[38,122],[43,83]],'#4b5750','#171d1b',2);
    shape(ctx,[[54,26],[63,26],[65,57],[72,63],[80,111],[97,154],[70,168],[62,122],[59,74]],'#313c36');
    shape(ctx,[[35,80],[49,69],[65,76],[72,103],[54,114],[37,104]],'#19221e','#7d8879',2);
    shape(ctx,[[41,82],[49,77],[59,81],[62,94],[53,101],[42,96]],'#304840','#929d82',1.6);
    line(ctx,48,90,54,90,'#e7ad64',1.2);
    for(let i=0;i<4;i++) line(ctx,43,115+i*7,60+i*2,114+i*7,'#687467',2);
    shape(ctx,[[66,135],[89,131],[106,143],[118,159],[112,178],[88,171],[70,155]],'#655b44','#242c23',2);
    shape(ctx,[[89,154],[123,149],[149,184],[116,192],[92,174]],'#35453a','#182820',2);
    if(game.flash>0) {
      const glow=ctx.createRadialGradient(47,20,2,47,20,57);
      glow.addColorStop(0,'rgba(255,214,129,.94)');glow.addColorStop(1,'rgba(255,145,53,0)');
      circle(ctx,47,20,57,glow);
      shape(ctx,[[41,22],[31,2],[42,7],[47,-22],[54,6],[68,-5],[58,15],[62,24]],'#fff0a8');
    }
    ctx.restore();
  }

  button(id,text,x,y,w,h,kind='outline') {
    const ctx=this.ctx;
    const fill=kind==='primary'?C.mint:kind==='dark'?'rgba(13,24,21,.91)':'rgba(17,28,25,.62)';
    rect(ctx,x,y,w,h,fill);
    ctx.lineWidth=1;ctx.strokeStyle=kind==='primary'?'#e5ffae':C.line;ctx.strokeRect(x+.5,y+.5,w-1,h-1);
    label(ctx,text,x+w/2,y+h/2,{size:kind==='primary'?15:13,weight:700,align:'center',color:kind==='primary'?'#202b1b':C.text,max:w-12});
    if(id) this.buttons.push({id,x,y,w,h});
  }

  hit(x,y) {
    return [...this.buttons].reverse().find(b=>x>=b.x && x<=b.x+b.w && y>=b.y && y<=b.y+b.h);
  }

  drawMap(game,x,y,w,h,expanded) {
    const ctx=this.ctx;
    const s=Math.min(w/WIDTH,h/HEIGHT), ox=x+(w-WIDTH*s)/2, oy=y+(h-HEIGHT*s)/2;
    rect(ctx,x,y,w,h,'rgba(15,27,24,.91)');
    for(let row=0;row<HEIGHT;row++) {
      for(let col=0;col<WIDTH;col++) {
        if(!materialAt(col,row)) continue;
        if (row===0 || row===HEIGHT-1 || col===0 || col===WIDTH-1) continue;
        rect(ctx,ox+col*s,oy+row*s,s+.22,s+.22,expanded?'#51665a':'#536359');
      }
    }
    if (expanded && game.path.length) {
      ctx.beginPath();ctx.moveTo(ox+game.player.x*s,oy+game.player.y*s);
      game.path.forEach(p=>ctx.lineTo(ox+p.x*s,oy+p.y*s));
      ctx.lineWidth=1.6;ctx.strokeStyle=C.mint;ctx.stroke();
    }
    const marks=game.relays.concat(game.cutCount===3?[BOAT]:[]);
    for(const mark of marks) {
      const mx=ox+mark.x*s,my=oy+mark.y*s;
      const color=mark.cut?'#6b9271':mark===BOAT?C.mint:C.orange;
      diamond(ctx,mx,my,expanded?6:2.8,color);
      if(expanded) label(ctx,mark.id,mx+10,my-6,{size:11,weight:800,color});
    }
    for (const unit of game.units) {
      if(unit.alert && distance(unit,game.player)<9) circle(ctx,ox+unit.x*s,oy+unit.y*s,expanded?2.6:1.4,C.red);
    }
    const px=ox+game.player.x*s,py=oy+game.player.y*s, r=expanded?7:4.2;
    ctx.save();ctx.translate(px,py);ctx.rotate(game.player.yaw);
    shape(ctx,[[r,0],[-r*.7,-r*.62],[-r*.41,0],[-r*.7,r*.62]],C.mint,'#223224');
    ctx.restore();
    if(expanded) this.mapSpace={ox,oy,s};
  }

  compass(game) {
    const ctx=this.ctx, mid=this.w/2, y=this.top+2;
    const directions=['东','东南','南','西南','西','西北','北','东北'];
    const count=clamp(Math.floor(this.w/19),14,28);
    for(let i=-count;i<=count;i++) {
      const sector=Math.round(game.player.yaw/(Math.PI/24))+i;
      const offset=angle(sector*Math.PI/24-game.player.yaw)*112;
      if(Math.abs(offset)>Math.min(108,this.w*.29)) continue;
      if(sector%6===0) label(ctx,directions[((sector/6)%8+8)%8],mid+offset,y+3,{align:'center',size:9,color:C.muted});
      const len=sector%6===0?6:sector%3===0?4:2;
      line(ctx,mid+offset,y+15,mid+offset,y+15+len,'rgba(224,235,216,.53)');
    }
    line(ctx,mid,y+13,mid,y+23,C.mint,1.6);
  }

  objectiveMarkers(game) {
    const ctx=this.ctx;
    const objectives=game.cutCount===3?[BOAT]:game.relays.filter(r=>!r.cut);
    const sorted=objectives.slice().sort((a,b)=>distance(a,game.player)-distance(b,game.player));
    const shownSide={};
    for(const [i,mark] of sorted.entries()) {
      const at=this.project(mark.x,mark.y,mark===BOAT?2.1:2.55);
      const d=distance(mark,game.player);
      const color=mark===BOAT?C.mint:C.orange;
      if(at && at.x>40 && at.x<this.w-40 && at.y>this.top+129 && at.y<this.h-140) {
        const y=clamp(at.y,this.top+136,this.h-154);
        if(i>0 && sorted.some((other,j)=>{
          if(j>=i)return false;
          const next=this.project(other.x,other.y,2.55);
          return next && Math.abs(next.x-at.x)<37 && Math.abs(next.y-y)<28;
        })) continue;
        diamond(ctx,at.x,y,10,'rgba(19,31,26,.88)',color);
        label(ctx,mark.id,at.x,y+.5,{align:'center',size:10,weight:800,color});
        label(ctx,`${Math.round(d)} m`,at.x,y+19,{align:'center',size:10,mono:true,color:C.text});
      } else if(i===0 || mark===BOAT) {
        const turn=angle(Math.atan2(mark.y-game.player.y,mark.x-game.player.x)-game.player.yaw);
        const side=Math.sign(turn)||1;
        if(shownSide[side]) continue;
        shownSide[side]=true;
        const x=side>0?this.right-8:this.left+8;
        const y=clamp(this.horizon-13,this.top+150,this.h*.69);
        shape(ctx,[[x+side*7,y],[x-side*2,y-5],[x-side*2,y+5]],color);
        label(ctx,`${mark.id}  ${Math.round(d)}m`,x-side*11,y,{align:side>0?'right':'left',size:10,weight:700,color});
      }
    }
  }

  reticle(game) {
    const ctx=this.ctx,x=this.w/2;
    // Pitch moves the projected world. The center of the sight stays fixed.
    const sightY=this.h*.45;
    const color=game.hitFlash>0?(game.hitWeak?C.orange:C.mint):game.target?C.mint:'rgba(243,245,223,.9)';
    const r=game.target?10:12;
    for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]) line(ctx,x+dx*5,sightY+dy*5,x+dx*r,sightY+dy*r,color,1.3);
    circle(ctx,x,sightY,1.3,color);
    if(game.hitFlash>0) {
      for(const [dx,dy] of [[-1,-1],[1,-1],[-1,1],[1,1]]) line(ctx,x+dx*9,sightY+dy*9,x+dx*14,sightY+dy*14,color,1.6);
    }
    if(game.hurtFlash>0) {
      const a=game.hurtAngle-Math.PI/2;
      ctx.globalAlpha=Math.min(1,game.hurtFlash*3);
      ctx.beginPath();ctx.arc(x,sightY,37,a-.48,a+.48);
      ctx.strokeStyle=C.red;ctx.lineWidth=3;ctx.stroke();
      const damage=ctx.createRadialGradient(x,sightY,Math.min(this.w,this.h)*.2,x,sightY,Math.max(this.w,this.h)*.65);
      damage.addColorStop(0,'rgba(239,64,41,0)');damage.addColorStop(1,'rgba(239,64,41,.43)');
      rect(ctx,0,0,this.w,this.h,damage);
      ctx.globalAlpha=1;
    }
  }

  movementStick(stick) {
    const ctx = this.ctx, {x, y, radius, travel} = this.stickLayout;
    circle(ctx,x,y,radius,'rgba(15,27,25,.62)',stick?C.mint:'rgba(217,233,211,.52)',1.2);
    circle(ctx,x,y,travel,null,'rgba(217,233,211,.2)');
    for (const [dx,dy] of [[0,-1],[1,0],[0,1],[-1,0]]) {
      line(ctx,x+dx*(radius-10),y+dy*(radius-10),x+dx*(radius-4),y+dy*(radius-4),'rgba(217,233,211,.55)',1.5);
    }
    const knobX = x + (stick?.strafe || 0) * travel;
    const knobY = y - (stick?.forward || 0) * travel;
    circle(ctx,knobX,knobY,17,stick?C.mint:'#263732',stick?'#edffbc':'#84998a',1.4);
    circle(ctx,knobX,knobY,4,stick?'#344729':'#c1cec0');
    this.buttons.push({id:'move-stick',x:x-radius,y:y-radius,w:radius*2,h:radius*2});
    return y-radius;
  }

  hud(game, stick) {
    const ctx=this.ctx,w=this.w,h=this.h,L=this.left,R=this.right,T=this.top,B=this.bottom;
    rect(ctx,0,0,w,T+136,gradient(ctx,0,0,0,T+136,[[0,'rgba(12,22,21,.87)'],[.68,'rgba(12,22,21,.26)'],[1,'rgba(12,22,21,0)']]));
    rect(ctx,0,B-113,w,h-B+113,gradient(ctx,0,B-113,0,h,[[0,'rgba(12,22,21,0)'],[1,'rgba(12,22,21,.92)']]));
    this.compass(game);
    this.button('pause','Ⅱ',R-44,T+25,44,44,'dark');
    label(ctx,'行动目标',L,T+34,{size:10,weight:700,color:C.mint});
    label(ctx,game.cutCount===3?'前往南侧撤离艇':'切断三处中继',L,T+55,{size:19,weight:800,max:R-L-126});
    for(const [i,relay] of game.relays.entries()) {
      const x=L+i*32,y=T+76;
      rect(ctx,x,y,25,21,relay.cut?'#405d38':'rgba(17,30,24,.81)');
      ctx.strokeStyle=relay.cut?'#9bbb7a':C.line;ctx.strokeRect(x+.5,y+.5,24,20);
      label(ctx,relay.cut?'✓':relay.id,x+12.5,y+10.5,{align:'center',size:10,weight:800,color:relay.cut?C.mint:C.muted});
    }
    label(ctx,formatTime(game.time),L+102,T+87,{size:11,mono:true,color:C.muted});
    const mapW=68,mapH=58,mapX=R-mapW,mapY=T+76;
    this.drawMap(game,mapX,mapY,mapW,mapH,false);
    brackets(ctx,mapX,mapY,mapW,mapH,C.line);
    this.buttons.push({id:'map',x:mapX-3,y:mapY-2,w:mapW+6,h:mapH+4});

    this.objectiveMarkers(game);
    this.reticle(game);
    const padTop=this.movementStick(stick);
    const hintY=h*.45+34;
    if(game.noticeUntil>game.time) label(ctx,game.notice,w/2,hintY,{align:'center',size:12,weight:700,color:C.orange,max:w-36});
    const dialogue=game.radioUntil>game.time ? game.radio : game.time<16 ? '拖动摇杆移动 · 拖动右侧转向 · 自动开火' : '';
    if(dialogue && !game.interaction && padTop-55>T+118) {
      const room=R-L;
      const y=Math.min(padTop-53,Math.max(h*.68,T+122));
      const long=dialogue.length>23 && room<360;
      const lines=long?[dialogue.slice(0,20),dialogue.slice(20)]:[dialogue];
      rect(ctx,L,y,room,long?47:36,'rgba(14,26,23,.84)');
      rect(ctx,L,y,2,long?47:36,C.mint);
      lines.forEach((text,i)=>label(ctx,text,L+10,y+(long?14:18)+i*17,{size:12,color:C.text,max:room-18}));
    }
    const use=game.nearby(), active=game.interaction;
    const actionY=B-94;
    if(active || use || game.path.length) {
      const text=active?`正在切断中继 ${active.objective.id}`:use?(use===BOAT?'登上撤离艇':`切断中继 ${use.id}`):'停止移动';
      const ww=Math.min(164,(R-L)*.44);
      this.button(active?null:use?'use':'stop',text,R-ww,actionY,ww,45,active?'dark':use?'primary':'dark');
      if(active) rect(ctx,R-ww+1,actionY+41,(ww-2)*clamp(active.elapsed/CUT_TIME,0,1),3,C.mint);
    }
    label(ctx,'生命',L,B-38,{size:10,color:C.muted});
    label(ctx,Math.ceil(game.player.hp),L,B-19,{size:23,mono:true,weight:800,color:game.player.hp<31?C.red:C.text});
    const meter=Math.min(110,(R-L)*.3);
    rect(ctx,L,B-4,meter,3,'#53645a');
    rect(ctx,L,B-4,meter*game.player.hp/100,3,game.player.hp<31?C.red:C.mint);
    label(ctx,game.reload?'换弹中':'KR-7 步枪',R,B-38,{size:10,align:'right',color:game.reload?C.orange:C.muted});
    label(ctx,`${String(game.ammo).padStart(2,'0')} / ${game.reserve}`,R,B-19,{size:21,mono:true,weight:800,align:'right',color:game.ammo<=4?C.orange:C.text});
    rect(ctx,R-meter,B-4,meter,3,'#53645a');
    rect(ctx,R-meter,B-4,meter*game.ammo/MAGAZINE,3,C.orange);
  }

  title(game) {
    const ctx=this.ctx,w=this.w,h=this.h,L=this.left,R=this.right,T=this.top,B=this.bottom;
    const pad=Math.max(6,Math.min(32,(R-L)*.065));
    const x=L+pad,end=R-pad, room=end-x;
    const compact=h<540;
    const topY=T+(compact?30:Math.min(105,h*.112));
    rect(ctx,0,0,w,h,gradient(ctx,0,0,0,h,[[0,'rgba(10,19,20,.74)'],[.42,'rgba(9,19,18,.1)'],[.64,'rgba(9,19,18,.04)'],[1,'rgba(8,15,14,.98)']]));
    brackets(ctx,L,T,R-L,B-T,C.line,13);
    label(ctx,'HARBOR RAID',x,T+15,{size:10,mono:true,weight:700,color:C.mint});
    label(ctx,'05:42',end,T+15,{size:10,mono:true,align:'right',color:C.muted});
    line(ctx,x,topY,end,topY,C.line);
    const size=clamp(Math.min(room*.18,h*.143),40,76);
    label(ctx,'航战之',x,topY+size*.52,{size:size*.56,weight:800,color:C.mint,max:room});
    label(ctx,'港区奇袭',x,topY+size*1.33,{size,weight:900,color:C.text,max:room});
    label(ctx,'切断三处中继，突破港区封锁。',x,topY+size*1.46+(compact?29:35),{size:13,color:C.muted,max:room});
    if(!compact) {
      const centerY=h*.57;
      brackets(ctx,w*.5-23,centerY-23,46,46,'rgba(215,230,205,.38)',8);
      circle(ctx,w*.5,centerY,1.2,'rgba(215,230,205,.63)');
    }
    const buttonW=Math.min(room,410), buttonY=B-(compact?110:132), btnX=x;
    this.button('deploy','开始行动   →',btnX,buttonY,buttonW,52,'primary');
    const gap=8;
    this.button('help','操作指南',btnX,buttonY+60,(buttonW-gap)/2,44);
    this.button('sound',this.sound?'音效  开':'音效  关',btnX+(buttonW+gap)/2,buttonY+60,(buttonW-gap)/2,44);
    if(game.best && !compact) label(ctx,`最快撤离  ${formatTime(game.best)}`,btnX,B-10,{size:10,mono:true,color:C.muted});
  }

  panel(game, mode) {
    const ctx=this.ctx,w=this.w,h=this.h;
    const W=Math.min(this.right-this.left,420), x=(w-W)/2;
    const y=Math.max(this.top+7,(h-(mode==='map'?420:mode==='help'?350:310))/2);
    const H=Math.min(this.bottom-y,mode==='map'?420:mode==='help'?350:310);
    rect(ctx,0,0,w,h,'rgba(8,17,16,.69)');
    rect(ctx,x,y,W,H,'#14211e');
    brackets(ctx,x,y,W,H,'#6c826d',12);
    const px=x+18,pw=W-36;
    if(mode==='map') {
      label(ctx,'港区地图',px,y+28,{size:23,weight:800});
      this.button('resume','关闭',x+W-68,y+8,57,44);
      const mapY=y+58,mapH=Math.max(40,H-122);
      this.drawMap(game,px,mapY,pw,mapH,true);
      this.buttons.push({id:'map-point',x:px,y:mapY,w:pw,h:mapH});
      label(ctx,'点地面或中继标记设置路线',px,y+H-44,{size:12,color:C.text,max:pw});
      label(ctx,'A 堆场  ·  B 仓库  ·  C 码头',px,y+H-23,{size:11,color:C.muted,max:pw});
      return;
    }
    if(mode==='help') {
      label(ctx,'操作指南',px,y+29,{size:24,weight:800});
      const rows=[
        ['拖动左下摇杆','可向任意方向移动，轻推慢走，松手即停。'],
        ['另一只手拖动画面','可边移动边转向，上下拖动抬枪或压枪。'],
        ['准星对准目标','步枪会自动开火，也会自行换弹。'],
        ['靠近中继或撤离艇','点底部动作按钮，停留到进度完成。'],
      ];
      rows.forEach(([title,body],i)=>{
        const row=y+64+i*(H<325?42:48);
        label(ctx,title,px,row,{size:13,weight:800,color:C.mint,max:pw});
        label(ctx,body,px,row+19,{size:12,color:C.muted,max:pw});
      });
      label(ctx,'受伤后躲入掩体，4 秒未受伤开始恢复。',px,y+H-73,{size:11,color:C.muted,max:pw});
      this.button('close-help','返回',px,y+H-57,pw,44,'primary');
      return;
    }
    const title=mode==='pause'?'行动暂停':mode==='win'?'撤离成功':'信号中断';
    const kicker=mode==='pause'?'港区奇袭':mode==='win'?'行动简报':'行动失败';
    label(ctx,kicker,px,y+26,{size:11,weight:700,color:mode==='lost'?C.orange:C.mint});
    label(ctx,title,px,y+55,{size:27,weight:900});
    if(mode==='pause') {
      const split=(pw-8)/2;
      this.button('resume','继续行动',px,y+86,pw,48,'primary');
      this.button('sound',this.sound?'音效  开':'音效  关',px,y+142,split,44);
      this.button('quality',this.highQuality?'画质  高':'画质  标准',px+split+8,y+142,split,44);
      this.button('help','操作指南',px,y+194,split,44);
      this.button('restart','返回主界面',px+split+8,y+194,split,44);
    } else {
      const grade=mode==='win'?(game.time<110&&game.player.hp>=65?'精准突击':game.time<160?'顺利撤离':'成功脱险'):`已切断 ${game.cutCount} / 3 处中继`;
      label(ctx,grade,px,y+91,{size:13,weight:700,color:mode==='win'?C.mint:C.muted});
      for(const [i,[name,value]] of [['用时',formatTime(game.time)],['摧毁',game.kills],['弱点命中',game.shots?Math.round(game.weakHits/game.shots*100)+'%':'—']].entries()) {
        const sx=px+i*pw/3;
        label(ctx,name,sx,y+129,{size:10,color:C.muted});
        label(ctx,value,sx,y+151,{size:20,mono:true,weight:800});
      }
      this.button('deploy',mode==='win'?'再次出击':'重试任务',px,y+H-108,pw,46,'primary');
      this.button('restart','返回主界面',px,y+H-54,pw,43);
    }
  }

  draw(game,clock,screen,sound,reduced,stick) {
    this.buttons=[];
    this.sound=sound;
    this.camera(game,clock);
    this.sky();
    this.ground();
    this.walls();
    this.worldObjects(game);
    this.weather(clock,reduced);
    if(game.mode!=='title') this.weapon(game);
    if(screen==='play') this.hud(game,stick);
    else if(screen==='title') this.title(game);
    else if(screen==='help' && game.mode==='title') this.title(game);
    if(!['play','title'].includes(screen)) {
      this.buttons=[];
      this.panel(game,screen);
    }
  }
}

module.exports={View,formatTime};
