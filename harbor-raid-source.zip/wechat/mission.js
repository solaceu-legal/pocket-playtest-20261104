'use strict';

const WIDTH = 36;
const HEIGHT = 29;
const START = { x: 4.5, y: 23.5, yaw: -0.42 };
const BOAT = { x: 32.5, y: 25.5, id: '撤', name: '撤离艇' };
const RELAYS = [
  { x: 11.5, y: 16.5, id: 'A', name: '集装箱堆场' },
  { x: 24.5, y: 9.5, id: 'B', name: '维修仓库' },
  { x: 30.5, y: 19.5, id: 'C', name: '南侧码头' },
];

const grid = Array.from({ length: HEIGHT }, () => new Uint8Array(WIDTH));
function fill(x, y, w, h, material) {
  for (let row = y; row < y + h; row++) grid[row].fill(material, x, x + w);
}
fill(0, 0, WIDTH, 1, 4);
fill(0, HEIGHT - 1, WIDTH, 1, 6);
fill(0, 0, 1, HEIGHT, 4);
fill(WIDTH - 1, 0, 1, HEIGHT, 6);

// Container rows, warehouse walls with three entrances, and quay cargo.
[
  [2, 13, 3, 8, 2], [6, 10, 6, 2, 1], [7, 14, 3, 3, 3],
  [8, 19, 2, 3, 2], [12, 20, 5, 2, 1], [13, 13, 2, 6, 2],
  [16, 8, 2, 8, 3], [11, 5, 6, 2, 2], [3, 5, 3, 4, 1],
  [20, 5, 10, 1, 4], [20, 6, 1, 3, 4], [20, 12, 1, 2, 4],
  [21, 13, 3, 1, 4], [27, 13, 3, 1, 4], [29, 6, 1, 5, 4],
  [29, 12, 1, 1, 4], [22, 7, 2, 1, 5], [26, 10, 2, 1, 5],
  [20, 17, 5, 2, 3], [19, 22, 3, 3, 2], [25, 20, 2, 3, 1],
  [29, 16, 4, 1, 2], [29, 22, 2, 1, 5], [31, 7, 2, 3, 3],
  [13, 25, 3, 1, 5], [24, 25, 2, 1, 5], [33, 22, 1, 2, 5],
  [6, 23, 2, 1, 5],
].forEach(args => fill(...args));

const SPAWNS = [
  [9.5, 12.5], [16.5, 17.5], [13.5, 23.5], [19.5, 10.5],
  [25.5, 15.5], [27.5, 7.5], [32.5, 13.5], [28.5, 24.5],
  [33.5, 19.5], [8.5, 6.5], [18.5, 24.5],
];
const WAVES = [
  ['gull', 'hound', 'gull', 'gull'],
  ['gull', 'hound', 'gull', 'hound', 'gull'],
  ['hound', 'gull', 'gull', 'hound', 'gull', 'hound', 'gull'],
];
const TYPES = {
  gull: { hp: 46, speed: 1.55, reach: 11, damage: 8, radius: 0.58, height: 2.18, interval: 2.35 },
  hound: { hp: 76, speed: 2.7, reach: 1.35, damage: 16, radius: 0.55, height: 0.72, interval: 1.12 },
};
const RADIO = [
  '第一处已断开。敌方增援正在接近。',
  '第二处已断开。小心两侧夹击。',
  '三处中继全部断开。去南侧登船，别停下来。',
];
const MAGAZINE = 24;
const RELOAD = 1.26;
const CUT_TIME = 2.4;
const USE_RANGE = 1.82;
const MAX_NAV = 68;
const TAU = Math.PI * 2;

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const angle = v => Math.atan2(Math.sin(v), Math.cos(v));
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const materialAt = (x, y) => grid[y]?.[x] ?? 4;
const walkable = (x, y, r = 0.22) =>
  !materialAt(Math.floor(x - r), Math.floor(y - r)) &&
  !materialAt(Math.floor(x + r), Math.floor(y - r)) &&
  !materialAt(Math.floor(x - r), Math.floor(y + r)) &&
  !materialAt(Math.floor(x + r), Math.floor(y + r));

function ray(x, y, dx, dy, skipCrates = false) {
  let mx = Math.floor(x), my = Math.floor(y);
  const sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1;
  const ix = Math.abs(1 / dx), iy = Math.abs(1 / dy);
  let tx = (dx < 0 ? x - mx : mx + 1 - x) * ix;
  let ty = (dy < 0 ? y - my : my + 1 - y) * iy;
  if (!dx) tx = Infinity;
  if (!dy) ty = Infinity;
  for (let i = 0; i < WIDTH + HEIGHT; i++) {
    let side, depth;
    if (tx < ty) { depth = tx; tx += ix; mx += sx; side = 0; }
    else { depth = ty; ty += iy; my += sy; side = 1; }
    const material = materialAt(mx, my);
    if (material && (!skipCrates || material !== 5)) {
      const u = side ? x + dx * depth : y + dy * depth;
      return { depth, material, side, u: u - Math.floor(u), mx, my };
    }
  }
  return { depth: 64, material: 4, side: 0, u: 0, mx, my };
}
function clear(a, b) {
  const d = distance(a, b);
  if (d < 0.03) return true;
  return ray(a.x, a.y, (b.x - a.x) / d, (b.y - a.y) / d).depth > d - 0.06;
}
function slide(body, dx, dy, radius) {
  if (walkable(body.x + dx, body.y, radius)) body.x += dx;
  if (walkable(body.x, body.y + dy, radius)) body.y += dy;
}

function route(from, to) {
  if (!walkable(to.x, to.y)) return null;
  if (clear(from, to)) {
    let direct = true;
    const steps = Math.ceil(distance(from, to) * 5);
    for (let i = 1; i <= steps; i++) {
      if (!walkable(from.x + (to.x - from.x) * i / steps, from.y + (to.y - from.y) * i / steps)) {
        direct = false;
        break;
      }
    }
    if (direct) return [to];
  }
  const start = Math.floor(from.y) * WIDTH + Math.floor(from.x);
  const goal = Math.floor(to.y) * WIDTH + Math.floor(to.x);
  if (start === goal) return [to];
  const previous = new Int16Array(WIDTH * HEIGHT).fill(-1);
  const queue = new Int16Array(WIDTH * HEIGHT);
  let head = 0, tail = 1;
  queue[0] = start;
  previous[start] = start;
  while (head < tail && previous[goal] === -1) {
    const id = queue[head++];
    for (const step of [1, -1, WIDTH, -WIDTH]) {
      const next = id + step;
      if (next < 0 || next >= previous.length || previous[next] !== -1) continue;
      if (materialAt(next % WIDTH, Math.floor(next / WIDTH))) continue;
      previous[next] = id;
      queue[tail++] = next;
    }
  }
  if (previous[goal] === -1) return null;
  const result = [to];
  for (let id = previous[goal]; id !== start; id = previous[id]) {
    result.push({ x: id % WIDTH + 0.5, y: Math.floor(id / WIDTH) + 0.5 });
  }
  return result.reverse();
}

class Mission {
  constructor(feedback) {
    this.feedback = feedback;
    this.mode = 'title';
    this.best = 0;
    this.reset();
  }

  reset() {
    this.player = { ...START, hp: 100, hurtAt: -99, pitch: 0 };
    this.relays = RELAYS.map(relay => ({ ...relay, cut: false }));
    this.path = [];
    this.destination = null;
    this.units = [];
    this.bolts = [];
    this.effects = [];
    this.queue = [];
    this.time = 0;
    this.cutCount = 0;
    this.interaction = null;
    this.ammo = MAGAZINE;
    this.reserve = 120;
    this.reload = 0;
    this.cooldown = 0;
    this.shots = 0;
    this.hits = 0;
    this.weakHits = 0;
    this.kills = 0;
    this.walk = 0;
    this.stepDistance = 0;
    this.motion = 0;
    this.flash = 0;
    this.hitFlash = 0;
    this.hitWeak = false;
    this.hurtFlash = 0;
    this.hurtAngle = 0;
    this.target = null;
    this.radio = '';
    this.radioUntil = 0;
    this.notice = '';
    this.noticeUntil = 0;
    this.firstContact = false;
    this.lowHealth = false;
    this.pursuit = 0;
    this.nextPursuit = 0;
    this.seed = 4207;
  }

  random() {
    this.seed = (Math.imul(this.seed, 1664525) + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }

  deploy() {
    this.reset();
    this.mode = 'play';
    this.say('切断三处中继，再到南侧码头登船。', 5);
    this.spawn('gull', { x: 10.1, y: 21.8 }, true);
    this.spawn('gull', { x: 23.5, y: 15.6 }, true);
    this.spawn('hound', { x: 16.5, y: 17.5 }, true);
  }

  say(message, seconds = 4) {
    this.radio = message;
    this.radioUntil = this.time + seconds;
  }

  show(message, seconds = 2) {
    this.notice = message;
    this.noticeUntil = this.time + seconds;
  }

  go(x, y) {
    const to = { x, y };
    const path = route(this.player, to);
    if (!path) { this.show('该处无法通行'); return false; }
    if (path.length > MAX_NAV) { this.show('请选近一点的地面'); return false; }
    this.interaction = null;
    this.destination = to;
    this.path = path;
    return true;
  }

  stop() {
    this.path = [];
    this.destination = null;
  }

  nearby() {
    if (this.cutCount === this.relays.length && distance(this.player, BOAT) < 2.05 && clear(this.player, BOAT)) return BOAT;
    return this.relays.find(relay => !relay.cut && distance(this.player, relay) <= USE_RANGE && clear(this.player, relay));
  }

  use() {
    const objective = this.nearby();
    if (!objective || this.interaction) return;
    this.stop();
    if (objective === BOAT) {
      this.mode = 'win';
      this.best = !this.best ? this.time : Math.min(this.best, this.time);
      this.feedback('win', this.best);
      return;
    }
    this.interaction = { objective, elapsed: 0 };
    this.feedback('use');
  }

  spawn(type, position, patrol = false) {
    const spec = TYPES[type];
    this.units.push({
      ...position, type, hp: spec.hp, max: spec.hp, phase: this.random() * TAU,
      rest: 0.55 + this.random() * 0.75, alert: !patrol, origin: position,
      heading: 0, hit: 0, wind: 0, path: [], repath: 0, stuck: 0,
    });
  }

  wave() {
    const p = this.player;
    const available = SPAWNS.map(([x, y]) => ({ x, y }))
      .filter(at => distance(p, at) > 6)
      .sort((a, b) => {
        const score = point => Math.abs(distance(p, point) - 9) + (clear(p, point) ? 4 : 0);
        return score(a) - score(b);
      });
    WAVES[this.cutCount - 1].forEach((type, index) => {
      this.queue.push({ type, position: available[index % available.length], at: this.time + 1.35 + index * 0.8 });
    });
    this.say(RADIO[this.cutCount - 1]);
    this.show('检测到增援', 2.5);
  }

  completeCut() {
    const relay = this.interaction.objective;
    relay.cut = true;
    this.interaction = null;
    this.cutCount++;
    this.reserve += 20;
    this.feedback(this.cutCount === this.relays.length ? 'relay-all' : 'relay');
    this.wave();
    if (this.cutCount === this.relays.length) {
      this.pursuit = 4;
      this.nextPursuit = this.time + 10;
    }
  }

  damage(amount, source) {
    if (this.mode !== 'play') return;
    this.player.hp = Math.max(0, this.player.hp - amount);
    this.player.hurtAt = this.time;
    this.hurtFlash = 0.45;
    this.hurtAngle = angle(Math.atan2(source.y - this.player.y, source.x - this.player.x) - this.player.yaw);
    this.feedback('hurt');
    if (this.player.hp <= 0) { this.mode = 'lost'; this.feedback('death'); }
    if (this.player.hp < 31 && !this.lowHealth) {
      this.lowHealth = true;
      this.say('生命过低。绕到掩体后，脱离火力即可恢复。');
    }
  }

  movePlayer(dt, input) {
    const p = this.player;
    const beforeX = p.x, beforeY = p.y;
    const speed = 4.15;
    if (input.forward || input.strafe) {
      this.stop();
      this.interaction = null;
      const scale = speed * dt / Math.max(1, Math.hypot(input.forward, input.strafe));
      slide(p, (Math.cos(p.yaw) * input.forward - Math.sin(p.yaw) * input.strafe) * scale,
        (Math.sin(p.yaw) * input.forward + Math.cos(p.yaw) * input.strafe) * scale, 0.22);
    } else if (this.path.length) {
      const next = this.path[0];
      const d = distance(p, next);
      if (d <= speed * dt) {
        p.x = next.x;
        p.y = next.y;
        this.path.shift();
        if (!this.path.length) this.destination = null;
      } else {
        const scale = speed * dt / d;
        slide(p, (next.x - p.x) * scale, (next.y - p.y) * scale, 0.22);
        if (Math.hypot(p.x - beforeX, p.y - beforeY) < 0.001) this.stop();
      }
    }
    const traveled = Math.hypot(p.x - beforeX, p.y - beforeY);
    this.motion += ((traveled > 0.003 ? 1 : 0) - this.motion) * Math.min(1, dt * 12);
    this.walk += traveled * 3;
    this.stepDistance += traveled;
    if (this.stepDistance >= 1.75) {
      this.stepDistance -= 1.75;
      this.feedback('step');
    }
  }

  findTarget() {
    const p = this.player;
    let best = null;
    for (const unit of this.units) {
      const d = distance(p, unit);
      if (d > 18 || d < 0.05) continue;
      const turn = Math.abs(angle(Math.atan2(unit.y - p.y, unit.x - p.x) - p.yaw));
      const spec = TYPES[unit.type];
      const height = spec.height + (unit.type === 'gull' ? Math.sin(this.time * 4 + unit.phase) * 0.15 : 0);
      const elevation = Math.atan2(height - 1.55, d) - p.pitch;
      const horizontal = Math.atan2(spec.radius, d) + 0.065;
      const vertical = Math.atan2(unit.type === 'gull' ? 0.32 : 0.38, d) + 0.085;
      if (turn > horizontal || Math.abs(elevation) > vertical || !clear(p, unit)) continue;
      const score = turn + Math.abs(elevation) * 0.55 + d * 0.007;
      if (!best || score < best.score) {
        const weak = turn < horizontal * 0.42 && Math.abs(elevation) < vertical * 0.48;
        best = { unit, weak, score };
      }
    }
    return best;
  }

  combat(dt, manualFire) {
    this.target = this.findTarget();
    this.cooldown = Math.max(0, this.cooldown - dt);
    if (this.reload > 0) {
      const before = this.reload;
      this.reload -= dt;
      if (before > .53 && this.reload <= .53) this.feedback('reload-in');
      if (before > .18 && this.reload <= .18) this.feedback('reload-bolt');
      if (this.reload <= 0) {
        const count = Math.min(MAGAZINE - this.ammo, this.reserve);
        this.reserve -= count;
        this.ammo += count;
        this.reload = 0;
      }
      return;
    }
    if (this.ammo < MAGAZINE && this.reserve > 0 && (!this.ammo || (!this.target && this.ammo <= 8))) {
      this.reload = RELOAD;
      this.feedback('reload-out');
      return;
    }
    if ((!this.target && !manualFire) || this.cooldown > 0 || !this.ammo) return;
    this.cooldown = 0.19;
    this.ammo--;
    this.shots++;
    this.flash = 0.085;
    this.feedback('shot');
    const target = this.target;
    if (!target) return;
    const unit = target.unit;
    const damage = target.weak ? 42 : 24;
    unit.hp -= damage;
    unit.alert = true;
    unit.hit = 0.12;
    this.feedback('hit');
    this.hits++;
    if (target.weak) this.weakHits++;
    this.hitFlash = 0.22;
    this.hitWeak = target.weak;
    if (unit.hp <= 0) {
      this.kills++;
      this.reserve += unit.type === 'hound' ? 9 : 5;
      this.effects.push({ x: unit.x, y: unit.y, height: TYPES[unit.type].height, end: this.time + 0.5 });
      this.units.splice(this.units.indexOf(unit), 1);
      this.target = null;
      this.show(target.weak ? '弱点命中 · 已摧毁' : '目标已摧毁', 1.2);
      this.feedback(unit.type + '-kill');
    }
  }

  enemies(dt) {
    const p = this.player;
    if (this.queue.length && this.units.length < 9 && this.queue[0].at <= this.time) {
      const incoming = this.queue.shift();
      this.spawn(incoming.type, incoming.position);
    }
    if (this.pursuit && this.time >= this.nextPursuit && this.units.length < 5 && !this.queue.length) {
      const at = SPAWNS.map(([x, y]) => ({ x, y })).filter(pos => distance(p, pos) > 6)
        .sort((a, b) => distance(p, a) - distance(p, b))[0];
      if (at) this.spawn(this.pursuit % 2 ? 'hound' : 'gull', at);
      this.pursuit--;
      this.nextPursuit = this.time + 7;
    }
    for (const unit of this.units) {
      const spec = TYPES[unit.type], d = distance(p, unit);
      const visible = d < 16 && clear(unit, p);
      unit.hit = Math.max(0, unit.hit - dt);
      if (visible && d < 11) unit.alert = true;
      if (!unit.alert) {
        const orbit = { x: unit.origin.x + Math.sin(this.time * 0.8 + unit.phase) * 0.48,
          y: unit.origin.y + Math.cos(this.time * 0.8 + unit.phase) * 0.48 };
        slide(unit, (orbit.x - unit.x) * dt, (orbit.y - unit.y) * dt, 0.23);
        continue;
      }
      if (!this.firstContact && visible) {
        this.firstContact = true;
        this.feedback('alert');
        this.say('发现机械飞鸥与猎犬。准星靠近敌人时自动开火。', 4);
      }
      unit.rest -= dt;
      if (unit.wind > 0) {
        unit.wind -= dt;
        if (unit.wind <= 0 && visible && d <= spec.reach + 0.2) {
          this.feedback(unit.type + '-fire');
          if (unit.type === 'hound') this.damage(spec.damage, unit);
          else this.bolts.push({ x: unit.x, y: unit.y, height: 2.02,
            dx: (p.x - unit.x) / d, dy: (p.y - unit.y) / d, ttl: 1.4, source: { x: unit.x, y: unit.y } });
        }
        continue;
      }
      if (visible && d < spec.reach && unit.rest <= 0) {
        unit.wind = unit.type === 'gull' ? 0.56 : 0.33;
        unit.rest = spec.interval + this.random() * 0.48;
        continue;
      }
      const gap = unit.type === 'gull' ? 6.0 : 0.85;
      if (visible && d < gap) continue;
      unit.repath -= dt;
      if (unit.repath <= 0) {
        unit.path = route(unit, p) || [];
        unit.repath = 0.7 + this.random() * 0.45;
      }
      const next = unit.path[0];
      if (!next) continue;
      const step = distance(unit, next);
      if (step < 0.13) { unit.path.shift(); continue; }
      const stride = Math.min(step, spec.speed * dt);
      const before = { x: unit.x, y: unit.y };
      slide(unit, (next.x - unit.x) * stride / step, (next.y - unit.y) * stride / step, 0.2);
      unit.stuck = distance(before, unit) < 0.001 ? unit.stuck + dt : 0;
      if (unit.stuck > 0.2) unit.repath = 0;
    }
    this.bolts = this.bolts.filter(bolt => {
      bolt.ttl -= dt;
      const stride = 10.5 * dt;
      if (ray(bolt.x, bolt.y, bolt.dx, bolt.dy).depth < stride) return false;
      bolt.x += bolt.dx * stride;
      bolt.y += bolt.dy * stride;
      bolt.height = Math.max(1.35, bolt.height - dt * 0.62);
      if (distance(p, bolt) < 0.38) { this.damage(TYPES.gull.damage, bolt.source); return false; }
      return bolt.ttl > 0;
    });
    this.effects = this.effects.filter(effect => effect.end > this.time);
  }

  update(dt, input) {
    if (this.mode !== 'play') return;
    const p = this.player;
    this.time += dt;
    this.flash = Math.max(0, this.flash - dt);
    this.hitFlash = Math.max(0, this.hitFlash - dt);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt);
    this.movePlayer(dt, input);
    if (this.interaction) {
      if (this.nearby() !== this.interaction.objective) this.interaction = null;
      else {
        this.interaction.elapsed += dt;
        if (this.interaction.elapsed >= CUT_TIME) this.completeCut();
      }
    }
    this.combat(dt, input.fire);
    this.enemies(dt);
    if (this.time - p.hurtAt > 4 && this.mode === 'play') p.hp = Math.min(100, p.hp + dt * 25);
  }
}

module.exports = { Mission, WIDTH, HEIGHT, RELAYS, BOAT, TYPES, CUT_TIME, MAGAZINE,
  clamp, angle, distance, ray, clear, materialAt, walkable, route };
